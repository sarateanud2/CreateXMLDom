package com.xml.dom;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class Main {

	public static void main(String[] args) {
		
		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.newDocument();
			
			//Root element
			Element rootElement = doc.createElement("cars");
			doc.appendChild(rootElement);
			
			//Supercars element
			Element superCar = doc.createElement("supercars");
			rootElement.appendChild(superCar);
			
			//Setting attribute to elements
			Attr attr = doc.createAttribute("company");
			attr.setValue("Ferrari");
			superCar.setAttributeNode(attr);
			
			//Carname element
			Element carname = doc.createElement("carname");
			Attr attrType1 = doc.createAttribute("type");
			attrType1.setValue("formula one");
			carname.setAttributeNode(attrType1);
			carname.appendChild(doc.createTextNode("Ferrai 101"));
			superCar.appendChild(carname);
			
			Element carname1 = doc.createElement("carname");
	        Attr attrType2 = doc.createAttribute("type");
	        attrType1.setValue("sports");
	        carname1.setAttributeNode(attrType2);
	        carname1.appendChild(
	        doc.createTextNode("Ferrari 202"));
	        superCar.appendChild(carname1);
	        
	        //write the content into xml file
	        TransformerFactory transformerFactory = TransformerFactory.newInstance();
	        Transformer transformer = transformerFactory.newTransformer();
	        
	        DOMSource source = new DOMSource(doc);
	        StreamResult result = new StreamResult(new File("inputXML.xml"));
	        transformer.transform(source, result);
	        
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
